 var requestPayload = context.getVariable("xmlData");
 context.setVariable("request.content",requestPayload);  
